# ============================================================
# Лабораторная работа 5
# Датасет KEEL cod=107: segment.dat
# Шаги 2-9: DataFrame, стандартизация, split 5/3/2,
# MLP, SVM, Keras, KAN, итоговое сравнение на validation
# ============================================================

# ============================================================
# 0. ПАРАМЕТРЫ, КОТОРЫЕ МОЖНО МЕНЯТЬ ВРУЧНУЮ
# ============================================================

DATASET_PATH = "/Users/barykingeorgij/Desktop/Машинное обучение 8 сем/Лаба5/segment.dat"
RANDOM_STATE = 22222

# Доли выборок по заданию: 5 / 3 / 2
TRAIN_SIZE = 0.5
TEST_SIZE = 0.3
VALID_SIZE = 0.2

# Общие параметры метрик
AVERAGE_TYPE = "macro"
ROC_AUC_MULTI_CLASS = "ovr"
ZERO_DIVISION = 0

# ------------------------------------------------------------
# Параметры подбора MLPClassifier
# ------------------------------------------------------------

MLP_SOLVERS = ["adam", "lbfgs"]
MLP_ALPHAS = [0.0001]
MLP_LEARNING_RATES = ["constant"]
MLP_LEARNING_RATE_INITS = [0.001]
MLP_HIDDEN_LAYER_SIZES = [
    (20,),
    (30, 15),
]
MLP_MAX_ITER = 500


# ------------------------------------------------------------
# Параметры подбора SVM
# ------------------------------------------------------------

SVM_KERNELS = ["linear", "rbf", "poly", "sigmoid"]
SVM_GAMMAS = ["scale", 0.1]
SVM_COEF0S = [0, 1]
SVM_DEGREES = [2, 3]
SVM_CS = [1, 10]

# probability=True нужен для predict_proba и ROC-AUC
SVM_PROBABILITY = True


# ------------------------------------------------------------
# Параметры Keras
# ------------------------------------------------------------

USE_KERAS = True

KERAS_EPOCHS_LIST = [80]
KERAS_BATCH_SIZES = [32]
KERAS_ARCHITECTURES = [
    [64],
    [64, 32],
]
KERAS_ACTIVATION = "relu"
KERAS_OPTIMIZER = "adam"
KERAS_VERBOSE = 0

# ------------------------------------------------------------
# Параметры KAN
# ------------------------------------------------------------

USE_KAN = True

DEVICE = "cpu"

KAN_WIDTHS = [
    [19, 8, 7],
    [19, 16, 7],
    [19, 32, 7],
    [19, 16, 8, 7],
]

KAN_GRIDS = [3, 5]
KAN_K_VALUES = [3]
KAN_OPTS = ["Adam"]
KAN_STEPS_LIST = [50, 100]
KAN_LR_LIST = [0.01, 0.005]
KAN_BATCHES = [128]

# ============================================================
# 1. ИМПОРТ БИБЛИОТЕК
# ============================================================

import warnings
warnings.filterwarnings("ignore")
import os
import contextlib

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.neural_network import MLPClassifier
from sklearn import svm

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    roc_auc_score,
    classification_report,
    confusion_matrix,
)

try:
    import tensorflow as tf
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.layers import Dense, Input
    from tensorflow.keras.utils import to_categorical
    from tensorflow.keras.callbacks import EarlyStopping
except Exception:
    USE_KERAS = False

try:
    import torch
    import torch.nn as nn
    from kan import KAN
except Exception:
    USE_KAN = False

# ============================================================
# ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# ============================================================

def print_block(title):
    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)


def read_keel_dat(path):
    """
    Читает .dat файл KEEL.
    Извлекает названия признаков из строк @attribute.
    Данные читает после строки @data.
    """
    attributes = []
    data_lines = []
    data_started = False

    with open(path, "r", encoding="utf-8", errors="ignore") as file:
        for raw_line in file:
            line = raw_line.strip()

            if not line:
                continue

            if line.lower().startswith("@attribute"):
                parts = line.split()
                attr_name = parts[1]
                attributes.append(attr_name)

            elif line.lower().startswith("@data"):
                data_started = True

            elif data_started:
                if not line.startswith("@") and not line.startswith("%"):
                    data_lines.append(line)

    rows = []
    for line in data_lines:
        row = [value.strip() for value in line.split(",")]
        rows.append(row)

    table = pd.DataFrame(rows, columns=attributes)

    return table


def evaluate_model(model_name, y_true, y_pred, y_proba=None, class_labels=None):
    """
    Считает Accuracy, Precision, Recall, ROC-AUC.
    Для многоклассовой задачи ROC-AUC считается по вероятностям классов.
    """
    result = {}

    result["Model"] = model_name
    result["Accuracy"] = accuracy_score(y_true, y_pred)
    result["Precision_macro"] = precision_score(
        y_true,
        y_pred,
        average=AVERAGE_TYPE,
        zero_division=ZERO_DIVISION,
    )
    result["Recall_macro"] = recall_score(
        y_true,
        y_pred,
        average=AVERAGE_TYPE,
        zero_division=ZERO_DIVISION,
    )

    if y_proba is not None:
        try:
            result["ROC_AUC_macro"] = roc_auc_score(
                y_true,
                y_proba,
                multi_class=ROC_AUC_MULTI_CLASS,
                average=AVERAGE_TYPE,
                labels=class_labels,
            )
        except Exception:
            result["ROC_AUC_macro"] = np.nan
    else:
        result["ROC_AUC_macro"] = np.nan

    return result


def print_model_report(model_name, y_true, y_pred):
    print("\n" + "-" * 80)
    print(model_name)
    print("-" * 80)
    print("Матрица ошибок:")
    print(confusion_matrix(y_true, y_pred))
    print("\nClassification report:")
    print(classification_report(y_true, y_pred, zero_division=ZERO_DIVISION))


def build_keras_model(input_dim, output_dim, hidden_layers):
    """
    Создает Keras-модель для многоклассовой классификации.
    """
    model = Sequential()
    model.add(Input(shape=(input_dim,)))

    for units in hidden_layers:
        model.add(Dense(units, activation=KERAS_ACTIVATION))

    model.add(Dense(output_dim, activation="softmax"))

    model.compile(
        optimizer=KERAS_OPTIMIZER,
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )

    return model

def predict_kan(model, X_tensor):
    """
    Возвращает предсказанные классы и вероятности классов.
    KAN возвращает logits, поэтому применяем softmax.
    """
    model.eval()
    with torch.no_grad():
        logits = model(X_tensor)
        probabilities = torch.softmax(logits, dim=1)
        y_pred = torch.argmax(probabilities, dim=1)

    return (
        y_pred.cpu().numpy(),
        probabilities.cpu().numpy(),
    )

# ============================================================
# 2. СОЗДАНИЕ PANDAS DATAFRAME И ПОДБОР ТИПОВ ДАННЫХ
# ============================================================

print_block("Шаг 2. Создание Pandas DataFrame и подбор типов данных")

table = read_keel_dat(DATASET_PATH)

print("Первые строки исходного DataFrame:")
print(table.head())

print("\nРазмер исходного DataFrame:")
print(table.shape)

print("\nСтолбцы:")
print(table.columns.tolist())

TARGET_COLUMN = "Class"
FEATURE_COLUMNS = [col for col in table.columns if col != TARGET_COLUMN]

# Признаки переводим в float.
for col in FEATURE_COLUMNS:
    table[col] = pd.to_numeric(table[col], errors="coerce")

# Целевой класс оставляем как категориальный признак.
table[TARGET_COLUMN] = table[TARGET_COLUMN].astype(str)

table = table.dropna().reset_index(drop=True)

# ============================================================
# 3. СТАНДАРТИЗАЦИЯ DATAFRAME
# ============================================================

print_block("Шаг 3. Стандартизация признаков")

X = table[FEATURE_COLUMNS].copy()
y_original = table[TARGET_COLUMN].copy()

# Кодируем классы числами: 0, 1, 2, ...
label_encoder = LabelEncoder()
y = label_encoder.fit_transform(y_original)

class_names = label_encoder.classes_
class_labels = np.arange(len(class_names))
n_classes = len(class_names)

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

scaled_table = pd.DataFrame(X_scaled, columns=FEATURE_COLUMNS)
scaled_table[TARGET_COLUMN] = y

print("\nДанные стандартизированы.")

print("\nПервые строки стандартизированного DataFrame:")
print(scaled_table.head())

# ============================================================
# 4. РАЗДЕЛЕНИЕ НА TRAIN / TEST / VALIDATION В СООТНОШЕНИИ 5 / 3 / 2
# ============================================================

print_block("Шаг 4. Разделение на обучающую, тестовую и валидационную выборки 5 / 3 / 2")

# Сначала отделяем train = 50%.
X_train, X_temp, y_train, y_temp = train_test_split(
    X_scaled,
    y,
    train_size=TRAIN_SIZE,
    random_state=RANDOM_STATE,
    stratify=y,
)

# Остаток 50% делим на test = 30% и validation = 20%.
# Внутри временной части доля test: 0.3 / (0.3 + 0.2) = 0.6.
test_part_inside_temp = TEST_SIZE / (TEST_SIZE + VALID_SIZE)

X_test, X_valid, y_test, y_valid = train_test_split(
    X_temp,
    y_temp,
    train_size=test_part_inside_temp,
    random_state=RANDOM_STATE,
    stratify=y_temp,
)

print(f"Размер всей выборки: {len(X_scaled)}")
print(f"Размер train:       {len(X_train)}")
print(f"Размер test:        {len(X_test)}")
print(f"Размер validation:  {len(X_valid)}")

print("\nРаспределение классов в train:")
print(pd.Series(y_train).value_counts().sort_index())

print("\nРаспределение классов в test:")
print(pd.Series(y_test).value_counts().sort_index())

print("\nРаспределение классов в validation:")
print(pd.Series(y_valid).value_counts().sort_index())


# ============================================================
# 5. MLP-КЛАССИФИКАТОР: ОБУЧЕНИЕ, ТЕСТИРОВАНИЕ, ПОДБОР ПАРАМЕТРОВ
# ============================================================

print_block("Шаг 5. MLP-классификатор: обучение, тестирование и подбор параметров")

mlp_results = []
best_mlp = None
best_mlp_result = None
best_mlp_params = None

for solver in MLP_SOLVERS:
    for alpha in MLP_ALPHAS:
        for learning_rate in MLP_LEARNING_RATES:
            for learning_rate_init in MLP_LEARNING_RATE_INITS:
                for hidden_layer_sizes in MLP_HIDDEN_LAYER_SIZES:

                    # Для lbfgs параметры learning_rate и learning_rate_init фактически не используются,
                    # но передача этих параметров не мешает работе модели.
                    clf = MLPClassifier(
                        solver=solver,
                        alpha=alpha,
                        learning_rate=learning_rate,
                        learning_rate_init=learning_rate_init,
                        hidden_layer_sizes=hidden_layer_sizes,
                        max_iter=MLP_MAX_ITER,
                        random_state=RANDOM_STATE,
                    )

                    try:
                        clf.fit(X_train, y_train)

                        y_pred = clf.predict(X_test)

                        if hasattr(clf, "predict_proba"):
                            y_proba = clf.predict_proba(X_test)
                        else:
                            y_proba = None

                        result = evaluate_model(
                            "MLP",
                            y_test,
                            y_pred,
                            y_proba,
                            class_labels=class_labels,
                        )

                        result["solver"] = solver
                        result["alpha"] = alpha
                        result["learning_rate"] = learning_rate
                        result["learning_rate_init"] = learning_rate_init
                        result["hidden_layer_sizes"] = hidden_layer_sizes

                        mlp_results.append(result)

                        # Основной критерий выбора: ROC-AUC macro.
                        # Если ROC-AUC не посчитался, используем Accuracy.
                        current_score = result["ROC_AUC_macro"]
                        if pd.isna(current_score):
                            current_score = result["Accuracy"]

                        if best_mlp_result is None:
                            best_mlp = clf
                            best_mlp_result = result
                            best_mlp_params = result
                        else:
                            best_score = best_mlp_result["ROC_AUC_macro"]
                            if pd.isna(best_score):
                                best_score = best_mlp_result["Accuracy"]

                            if current_score > best_score:
                                best_mlp = clf
                                best_mlp_result = result
                                best_mlp_params = result

                    except Exception as error:
                        print(f"Ошибка MLP: solver={solver}, alpha={alpha}, layers={hidden_layer_sizes}")
                        print(error)

mlp_results_df = pd.DataFrame(mlp_results)
mlp_results_df = mlp_results_df.sort_values(
    by=["ROC_AUC_macro", "Accuracy"],
    ascending=False,
)

print("\nТоп-10 MLP по результатам на test:")
print(mlp_results_df.head(10))

print("\nЛучшие параметры MLP:")
print(best_mlp_params)

y_test_pred_mlp = best_mlp.predict(X_test)
print_model_report("Лучший MLP на test", y_test, y_test_pred_mlp)


# ============================================================
# 6. SVM-КЛАССИФИКАТОР: ОБУЧЕНИЕ, ТЕСТИРОВАНИЕ, ПОДБОР ПАРАМЕТРОВ
# ============================================================

print_block("Шаг 6. SVM-классификатор: обучение, тестирование и подбор параметров")

svm_results = []
best_svm = None
best_svm_result = None
best_svm_params = None

for kernel in SVM_KERNELS:
    for gamma in SVM_GAMMAS:
        for coef0 in SVM_COEF0S:
            for degree in SVM_DEGREES:
                for C in SVM_CS:

                    clf = svm.SVC(
                        kernel=kernel,
                        gamma=gamma,
                        coef0=coef0,
                        degree=degree,
                        C=C,
                        probability=SVM_PROBABILITY,
                        random_state=RANDOM_STATE,
                    )

                    try:
                        clf.fit(X_train, y_train)

                        y_pred = clf.predict(X_test)

                        if hasattr(clf, "predict_proba"):
                            y_proba = clf.predict_proba(X_test)
                        else:
                            y_proba = None

                        result = evaluate_model(
                            "SVM",
                            y_test,
                            y_pred,
                            y_proba,
                            class_labels=class_labels,
                        )

                        result["kernel"] = kernel
                        result["gamma"] = gamma
                        result["coef0"] = coef0
                        result["degree"] = degree
                        result["C"] = C

                        svm_results.append(result)

                        current_score = result["ROC_AUC_macro"]
                        if pd.isna(current_score):
                            current_score = result["Accuracy"]

                        if best_svm_result is None:
                            best_svm = clf
                            best_svm_result = result
                            best_svm_params = result
                        else:
                            best_score = best_svm_result["ROC_AUC_macro"]
                            if pd.isna(best_score):
                                best_score = best_svm_result["Accuracy"]

                            if current_score > best_score:
                                best_svm = clf
                                best_svm_result = result
                                best_svm_params = result

                    except Exception as error:
                        print(
                            f"Ошибка SVM: kernel={kernel}, gamma={gamma}, "
                            f"coef0={coef0}, degree={degree}, C={C}"
                        )
                        print(error)

svm_results_df = pd.DataFrame(svm_results)
svm_results_df = svm_results_df.sort_values(
    by=["ROC_AUC_macro", "Accuracy"],
    ascending=False,
)

print("\nТоп-10 SVM по результатам на test:")
print(svm_results_df.head(10))

print("\nЛучшие параметры SVM:")
print(best_svm_params)

y_test_pred_svm = best_svm.predict(X_test)
print_model_report("Лучший SVM на test", y_test, y_test_pred_svm)


# ============================================================
# 7. KERAS: ПОСТРОЕНИЕ, ОБУЧЕНИЕ И ПОДБОР НЕЙРОСЕТИ
# ============================================================

print_block("Шаг 7. Keras: построение, обучение и подбор нейросети")

best_keras_model = None
best_keras_result = None
best_keras_params = None
keras_results = []

if USE_KERAS:
    # Для Keras нужен one-hot формат целевой переменной.
    y_train_cat = to_categorical(y_train, num_classes=n_classes)
    y_test_cat = to_categorical(y_test, num_classes=n_classes)

    input_dim = X_train.shape[1]
    output_dim = n_classes

    early_stop = EarlyStopping(
        monitor="val_loss",
        patience=15,
        restore_best_weights=True,
    )

    for architecture in KERAS_ARCHITECTURES:
        for batch_size in KERAS_BATCH_SIZES:
            for epochs in KERAS_EPOCHS_LIST:

                try:
                    # Фиксируем seed для большей воспроизводимости.
                    tf.keras.utils.set_random_seed(RANDOM_STATE)

                    model = build_keras_model(
                        input_dim=input_dim,
                        output_dim=output_dim,
                        hidden_layers=architecture,
                    )

                    model.fit(
                        X_train,
                        y_train_cat,
                        validation_data=(X_test, y_test_cat),
                        epochs=epochs,
                        batch_size=batch_size,
                        verbose=KERAS_VERBOSE,
                        callbacks=[early_stop],
                    )

                    y_proba = model.predict(X_test, verbose=0)
                    y_pred = np.argmax(y_proba, axis=1)

                    result = evaluate_model(
                        "Keras",
                        y_test,
                        y_pred,
                        y_proba,
                        class_labels=class_labels,
                    )

                    result["architecture"] = architecture
                    result["batch_size"] = batch_size
                    result["epochs"] = epochs

                    keras_results.append(result)

                    current_score = result["ROC_AUC_macro"]
                    if pd.isna(current_score):
                        current_score = result["Accuracy"]

                    if best_keras_result is None:
                        best_keras_model = model
                        best_keras_result = result
                        best_keras_params = result
                    else:
                        best_score = best_keras_result["ROC_AUC_macro"]
                        if pd.isna(best_score):
                            best_score = best_keras_result["Accuracy"]

                        if current_score > best_score:
                            best_keras_model = model
                            best_keras_result = result
                            best_keras_params = result

                except Exception as error:
                    print(
                        f"Ошибка Keras: architecture={architecture}, "
                        f"batch_size={batch_size}, epochs={epochs}"
                    )
                    print(error)

    keras_results_df = pd.DataFrame(keras_results)
    keras_results_df = keras_results_df.sort_values(
        by=["ROC_AUC_macro", "Accuracy"],
        ascending=False,
    )

    print("\nТоп Keras по результатам на test:")
    print(keras_results_df.head(10))

    print("\nЛучшие параметры Keras:")
    print(best_keras_params)

    y_test_proba_keras = best_keras_model.predict(X_test, verbose=0)
    y_test_pred_keras = np.argmax(y_test_proba_keras, axis=1)

    print_model_report("Лучшая Keras-модель на test", y_test, y_test_pred_keras)

else:
    print("Keras/TensorFlow не установлен или недоступен. Шаг 7 пропущен.")
    print("Для установки обычно используется команда:")
    print("python3 -m pip install tensorflow")


# ============================================================
# 8. KAN: ОБУЧЕНИЕ, ТЕСТИРОВАНИЕ И ПОДБОР ПАРАМЕТРОВ
# ============================================================

print_block("Шаг 8. Kolmogorov-Arnold Networks (KAN): обучение и подбор параметров")

best_kan_model = None
best_kan_result = None
best_kan_params = None
kan_results = []

if USE_KAN:
    torch.manual_seed(RANDOM_STATE)
    np.random.seed(RANDOM_STATE)

    X_train_t = torch.tensor(X_train, dtype=torch.float32).to(DEVICE)
    X_test_t = torch.tensor(X_test, dtype=torch.float32).to(DEVICE)
    X_valid_t = torch.tensor(X_valid, dtype=torch.float32).to(DEVICE)

    y_train_t = torch.tensor(y_train, dtype=torch.long).to(DEVICE)
    y_test_t = torch.tensor(y_test, dtype=torch.long).to(DEVICE)
    y_valid_t = torch.tensor(y_valid, dtype=torch.long).to(DEVICE)

    loss_fn = nn.CrossEntropyLoss()

    for width in KAN_WIDTHS:
        for grid in KAN_GRIDS:
            for k in KAN_K_VALUES:
                for opt in KAN_OPTS:
                    for steps in KAN_STEPS_LIST:
                        for lr in KAN_LR_LIST:
                            for batch in KAN_BATCHES:

                                #print("\nПроверяется KAN:")
                                #print(
                                #    f"width={width}, grid={grid}, k={k}, "
                                #    f"opt={opt}, steps={steps}, lr={lr}, batch={batch}"
                                #)

                                try:
                                    torch.manual_seed(RANDOM_STATE)
                                    np.random.seed(RANDOM_STATE)

                                    width_for_model = list(width)

                                    model = KAN(
                                        width=width_for_model,
                                        grid=grid,
                                        k=k,
                                        seed=RANDOM_STATE,
                                        device=DEVICE,
                                        symbolic_enabled=False,
                                        save_act=False,
                                        auto_save=False,
                                    )

                                    dataset = {
                                        "train_input": X_train_t,
                                        "train_label": y_train_t,
                                        "test_input": X_test_t,
                                        "test_label": y_test_t,
                                    }

                                    with open(os.devnull, "w") as devnull:
                                        with contextlib.redirect_stdout(devnull), contextlib.redirect_stderr(devnull):
                                            model.fit(
                                                dataset,
                                                opt=opt,
                                                steps=steps,
                                                loss_fn=loss_fn,
                                                lr=lr,
                                                batch=batch,
                                                log=max(1, steps // 10),
                                                update_grid=True,
                                            )

                                    y_test_pred, y_test_proba = predict_kan(model, X_test_t)

                                    result = evaluate_model(
                                        "KAN",
                                        y_test,
                                        y_test_pred,
                                        y_test_proba,
                                        class_labels=class_labels,
                                    )

                                    result["width"] = str(width)
                                    result["grid"] = grid
                                    result["k"] = k
                                    result["opt"] = opt
                                    result["steps"] = steps
                                    result["lr"] = lr
                                    result["batch"] = batch

                                    kan_results.append(result)

                                    current_score = result["ROC_AUC_macro"]
                                    if pd.isna(current_score):
                                        current_score = result["Accuracy"]

                                    if best_kan_result is None:
                                        best_kan_model = model
                                        best_kan_result = result
                                        best_kan_params = result
                                    else:
                                        best_score = best_kan_result["ROC_AUC_macro"]
                                        if pd.isna(best_score):
                                            best_score = best_kan_result["Accuracy"]

                                        if current_score > best_score:
                                            best_kan_model = model
                                            best_kan_result = result
                                            best_kan_params = result

                                    #print("Результат KAN на test:")
                                    #print(result)

                                except Exception as error:
                                    print("Ошибка при обучении KAN:")
                                    print(error)

    if len(kan_results) > 0:
        kan_results_df = pd.DataFrame(kan_results)
        kan_results_df = kan_results_df.sort_values(
            by=["ROC_AUC_macro", "Accuracy"],
            ascending=False,
        )

        print("\nТоп-10 KAN по результатам на test:")
        print(kan_results_df.head(10))

        print("\nЛучшие параметры KAN:")
        print(best_kan_params)

        y_test_pred_kan, y_test_proba_kan = predict_kan(best_kan_model, X_test_t)
        print_model_report("Лучшая KAN-модель на test", y_test, y_test_pred_kan)

        kan_results_df.to_csv("kan_test_results.csv", index=False, encoding="utf-8-sig")

    else:
        print("Ни одна KAN-модель не обучилась.")
        USE_KAN = False

else:
    print("KAN не выполняется. Проверь установку torch, pykan, pyyaml, tqdm.")

# ============================================================
# 9. ИТОГОВАЯ ОЦЕНКА ЛУЧШИХ МОДЕЛЕЙ НА VALIDATION
# ============================================================

print_block("Шаг 9. Оценка лучших моделей на валидационной выборке")

final_results = []

# ------------------------------------------------------------
# Validation: MLP
# ------------------------------------------------------------

y_valid_pred_mlp = best_mlp.predict(X_valid)
y_valid_proba_mlp = best_mlp.predict_proba(X_valid)

mlp_valid_result = evaluate_model(
    "Best MLP",
    y_valid,
    y_valid_pred_mlp,
    y_valid_proba_mlp,
    class_labels=class_labels,
)
final_results.append(mlp_valid_result)

print_model_report("Лучший MLP на validation", y_valid, y_valid_pred_mlp)

# ------------------------------------------------------------
# Validation: SVM
# ------------------------------------------------------------

y_valid_pred_svm = best_svm.predict(X_valid)
y_valid_proba_svm = best_svm.predict_proba(X_valid)

svm_valid_result = evaluate_model(
    "Best SVM",
    y_valid,
    y_valid_pred_svm,
    y_valid_proba_svm,
    class_labels=class_labels,
)
final_results.append(svm_valid_result)

print_model_report("Лучший SVM на validation", y_valid, y_valid_pred_svm)

# ------------------------------------------------------------
# Validation: Keras
# ------------------------------------------------------------

if USE_KERAS and best_keras_model is not None:
    y_valid_proba_keras = best_keras_model.predict(X_valid, verbose=0)
    y_valid_pred_keras = np.argmax(y_valid_proba_keras, axis=1)

    keras_valid_result = evaluate_model(
        "Best Keras",
        y_valid,
        y_valid_pred_keras,
        y_valid_proba_keras,
        class_labels=class_labels,
    )
    final_results.append(keras_valid_result)

    print_model_report("Лучшая Keras-модель на validation", y_valid, y_valid_pred_keras)

# ------------------------------------------------------------
# Validation: KAN
# ------------------------------------------------------------

if USE_KAN and best_kan_model is not None:
    y_valid_pred_kan, y_valid_proba_kan = predict_kan(best_kan_model, X_valid_t)

    kan_valid_result = evaluate_model(
        "Best KAN",
        y_valid,
        y_valid_pred_kan,
        y_valid_proba_kan,
        class_labels=class_labels,
    )

    final_results.append(kan_valid_result)

    print_model_report("Лучшая KAN-модель на validation", y_valid, y_valid_pred_kan)

    pd.DataFrame([kan_valid_result]).to_csv(
        "kan_validation_result.csv",
        index=False,
        encoding="utf-8-sig",
    )

else:
    print("\nKAN отсутствует в итоговой таблице, так как блок KAN не выполнялся.")
# ------------------------------------------------------------
# Итоговая таблица
# ------------------------------------------------------------

final_results_df = pd.DataFrame(final_results)
final_results_df = final_results_df.sort_values(
    by=["Accuracy", "Precision_macro", "Recall_macro", "ROC_AUC_macro"],
    ascending=False,
)

print("\n" + "=" * 80)
print("ИТОГОВОЕ СРАВНЕНИЕ ЛУЧШИХ МОДЕЛЕЙ НА VALIDATION")
print("=" * 80)
print(final_results_df)

print("\nЛучшие параметры MLP:")
print(best_mlp_params)

print("\nЛучшие параметры SVM:")
print(best_svm_params)

if USE_KERAS and best_keras_params is not None:
    print("\nЛучшие параметры Keras:")
    print(best_keras_params)

if USE_KAN and best_kan_params is not None:
    print("\nЛучшие параметры KAN:")
    print(best_kan_params)
    
print("\nРабота завершена.")